from django.apps import AppConfig


class TrainerdbappConfig(AppConfig):
    name = 'trainerdbapp'
