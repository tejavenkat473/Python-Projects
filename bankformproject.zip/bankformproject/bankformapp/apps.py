from django.apps import AppConfig


class BankformappConfig(AppConfig):
    name = 'bankformapp'
