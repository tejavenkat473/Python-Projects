from django.apps import AppConfig


class StudentinfoappConfig(AppConfig):
    name = 'studentinfoapp'
